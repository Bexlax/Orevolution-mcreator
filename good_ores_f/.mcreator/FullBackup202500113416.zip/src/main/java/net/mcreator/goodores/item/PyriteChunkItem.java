
package net.mcreator.goodores.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PyriteChunkItem extends Item {
	public PyriteChunkItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON).stacksTo(64));
	}
}
