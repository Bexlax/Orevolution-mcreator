
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.goodores.init;

import net.neoforged.neoforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;

@EventBusSubscriber
public class GoodOresModFuels {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		ItemStack itemstack = event.getItemStack();
		if (itemstack.getItem() == GoodOresModItems.PYRITE_CHUNK.get())
			event.setBurnTime(43200);
		else if (itemstack.getItem() == GoodOresModItems.PYRITE_FRAGMENT.get())
			event.setBurnTime(4800);
	}
}
