
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.goodores.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.goodores.potion.IronArmorEffectMobEffect;
import net.mcreator.goodores.potion.GoldPickaxeEffectMobEffect;
import net.mcreator.goodores.potion.ChainmailArmorEffectMobEffect;
import net.mcreator.goodores.potion.BleedingMobEffect;
import net.mcreator.goodores.GoodOresMod;

public class GoodOresModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, GoodOresMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> GOLD_PICKAXE_EFFECT = REGISTRY.register("gold_pickaxe_effect", () -> new GoldPickaxeEffectMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> IRON_ARMOR_EFFECT = REGISTRY.register("iron_armor_effect", () -> new IronArmorEffectMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> CHAINMAIL_ARMOR_EFFECT = REGISTRY.register("chainmail_armor_effect", () -> new ChainmailArmorEffectMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> BLEEDING = REGISTRY.register("bleeding", () -> new BleedingMobEffect());
}
