
package net.mcreator.goodores.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ExperienceCrystalItem extends Item {
	public ExperienceCrystalItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE).stacksTo(1));
	}
}
