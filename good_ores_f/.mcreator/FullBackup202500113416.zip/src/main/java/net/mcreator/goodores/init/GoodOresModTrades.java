
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.goodores.init;

import net.neoforged.neoforge.event.village.VillagerTradesEvent;
import net.neoforged.neoforge.common.BasicItemListing;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerProfession;

@EventBusSubscriber
public class GoodOresModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == VillagerProfession.ARMORER) {
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(GoodOresModItems.PLATINUM_INGOT.get(), 2), new ItemStack(Items.EMERALD), 12, 10, 0.04f));
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Items.EMERALD, 16), new ItemStack(GoodOresModItems.PLATINUM_ARMOR_CHESTPLATE.get()), 4, 15, 0.02f));
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Items.EMERALD, 11), new ItemStack(GoodOresModItems.PLATINUM_ARMOR_HELMET.get()), 4, 10, 0.02f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 14), new ItemStack(GoodOresModItems.PLATINUM_ARMOR_LEGGINGS.get()), 4, 15, 0.02f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 9), new ItemStack(GoodOresModItems.PLATINUM_ARMOR_BOOTS.get()), 4, 10, 0.02f));
		}
		if (event.getType() == VillagerProfession.WEAPONSMITH) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Items.EMERALD, 21), new ItemStack(GoodOresModItems.PLATINUM_SWORD.get()), 8, 12, 0.07f));
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Items.EMERALD, 26), new ItemStack(GoodOresModItems.PLATINUM_AXE.get()), 8, 14, 0.07f));
		}
		if (event.getType() == VillagerProfession.TOOLSMITH) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(GoodOresModItems.TIN_INGOT.get(), 8), new ItemStack(Items.EMERALD), 14, 3, 0.05f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(Items.EMERALD, 4), new ItemStack(GoodOresModItems.TIN_AXE.get()), 11, 5, 0.02f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(Items.EMERALD, 3), new ItemStack(GoodOresModItems.TIN_SHOVEL.get()), 11, 5, 0.02f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(Items.EMERALD, 5), new ItemStack(GoodOresModItems.TIN_PICKAXE.get()), 11, 5, 0.03f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(Items.EMERALD, 2), new ItemStack(GoodOresModItems.TIN_HOE.get()), 11, 5, 0.01f));
		}
	}
}
