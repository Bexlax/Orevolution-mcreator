
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.goodores.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.core.registries.Registries;

import net.mcreator.goodores.world.features.TungstenOrePlacementFeature;
import net.mcreator.goodores.world.features.TinOrePlacementFeature;
import net.mcreator.goodores.world.features.PlatinumOrePlacementFeature;
import net.mcreator.goodores.GoodOresMod;

public class GoodOresModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(Registries.FEATURE, GoodOresMod.MODID);
	public static final DeferredHolder<Feature<?>, Feature<?>> TIN_ORE_PLACEMENT = REGISTRY.register("tin_ore_placement", TinOrePlacementFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> PLATINUM_ORE_PLACEMENT = REGISTRY.register("platinum_ore_placement", PlatinumOrePlacementFeature::new);
	public static final DeferredHolder<Feature<?>, Feature<?>> TUNGSTEN_ORE_PLACEMENT = REGISTRY.register("tungsten_ore_placement", TungstenOrePlacementFeature::new);
}
