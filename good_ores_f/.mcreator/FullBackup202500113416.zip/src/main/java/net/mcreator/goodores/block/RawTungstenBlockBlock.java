
package net.mcreator.goodores.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class RawTungstenBlockBlock extends Block {
	public RawTungstenBlockBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.STONE).strength(5f, 6f).requiresCorrectToolForDrops());
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}
