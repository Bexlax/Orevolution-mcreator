
package net.mcreator.goodores.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.goodores.procedures.LumifloraToolEffectProcedure;

public class LumifloraSwordItem extends SwordItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1642, 8f, 0, 14, TagKey.create(Registries.ITEM, ResourceLocation.parse("good_ores:lumiflora_sword_repair_items")));

	public LumifloraSwordItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 5f, -2.4f, properties.fireResistant());
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		LumifloraToolEffectProcedure.execute(entity);
		return retval;
	}
}
