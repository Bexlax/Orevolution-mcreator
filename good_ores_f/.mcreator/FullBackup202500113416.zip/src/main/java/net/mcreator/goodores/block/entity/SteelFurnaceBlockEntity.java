
package net.mcreator.goodores.block.entity;

import net.neoforged.neoforge.items.wrapper.SidedInvWrapper;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.ContainerHelper;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.NonNullList;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.goodores.init.GoodOresModBlockEntities;

import javax.annotation.Nullable;

import java.util.stream.IntStream;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.inventory.FurnaceMenu;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import net.minecraft.core.RegistryAccess;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.entity.FuelValues;

public class SteelFurnaceBlockEntity extends AbstractFurnaceBlockEntity {
    public SteelFurnaceBlockEntity(BlockPos p_155545_, BlockState p_155546_) {
        super(GoodOresModBlockEntities.STEEL_FURNACE.get(), p_155545_, p_155546_, RecipeType.SMELTING);
    }

    public SidedInvWrapper getItemHandler() {
		return null;
	}
 
    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.good_ores.furnace");
    }

    @Override
    protected int getBurnDuration(FuelValues values,ItemStack fuel) {
        return super.getBurnDuration(values, fuel) * 3; // Doubles burn time
    }

    @Override
    protected AbstractContainerMenu createMenu(int p_59293_, Inventory p_59294_) {
        return new FurnaceMenu(p_59293_, p_59294_, this, this.dataAccess);
    }
}
