
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.goodores.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.goodores.client.model.Modellivingstone_armor;
import net.mcreator.goodores.client.model.Modelarmor_reinforced_netherite;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class GoodOresModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelarmor_reinforced_netherite.LAYER_LOCATION, Modelarmor_reinforced_netherite::createBodyLayer);
		event.registerLayerDefinition(Modellivingstone_armor.LAYER_LOCATION, Modellivingstone_armor::createBodyLayer);
	}
}
