package net.mcreator.goodores.init;

import net.neoforged.fml.event.lifecycle.FMLConstructModEvent;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.ModList;
import net.neoforged.bus.api.SubscribeEvent;

import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;
import net.mcreator.goodores.GoodOresMod;

@EventBusSubscriber(modid = GoodOresMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public class GoodOresModConfigs {
	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			ModList.get().getModContainerById("good_ores").get().registerConfig(ModConfig.Type.COMMON, GoodOresConfigConfiguration.SPEC, "Configvolution.toml");
		});
	}
}
