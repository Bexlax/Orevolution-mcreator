
/*
*    MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.goodores.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.client.event.RegisterRangeSelectItemModelPropertyEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.goodores.item.VerditeSwordItem;
import net.mcreator.goodores.item.VerditeShovelItem;
import net.mcreator.goodores.item.VerditePickaxeItem;
import net.mcreator.goodores.item.VerditeNuggetItem;
import net.mcreator.goodores.item.VerditeIngotItem;
import net.mcreator.goodores.item.VerditeHoeItem;
import net.mcreator.goodores.item.VerditeAxeItem;
import net.mcreator.goodores.item.VerditeArmorItem;
import net.mcreator.goodores.item.VerditeAppleItem;
import net.mcreator.goodores.item.TungstenPlaqueItem;
import net.mcreator.goodores.item.TungstenNuggetItem;
import net.mcreator.goodores.item.TungstenIngotItem;
import net.mcreator.goodores.item.TumbagaSwordItem;
import net.mcreator.goodores.item.TumbagaShovelItem;
import net.mcreator.goodores.item.TumbagaPickaxeItem;
import net.mcreator.goodores.item.TumbagaIngotItem;
import net.mcreator.goodores.item.TumbagaHoeItem;
import net.mcreator.goodores.item.TumbagaChiselItem;
import net.mcreator.goodores.item.TumbagaAxeItem;
import net.mcreator.goodores.item.TinSwordItem;
import net.mcreator.goodores.item.TinShovelItem;
import net.mcreator.goodores.item.TinPickaxeItem;
import net.mcreator.goodores.item.TinNuggetItem;
import net.mcreator.goodores.item.TinIngotItem;
import net.mcreator.goodores.item.TinHoeItem;
import net.mcreator.goodores.item.TinAxeItem;
import net.mcreator.goodores.item.SteelPlaqueItem;
import net.mcreator.goodores.item.SteelIngotItem;
import net.mcreator.goodores.item.SteelHammerItem;
import net.mcreator.goodores.item.SteelGiantswordItem;
import net.mcreator.goodores.item.SteelDiggerItem;
import net.mcreator.goodores.item.SteelArmorItem;
import net.mcreator.goodores.item.RustyPickaxeItem;
import net.mcreator.goodores.item.RustyAxeItem;
import net.mcreator.goodores.item.ReinforcedNetheriteArmorItem;
import net.mcreator.goodores.item.RawTungstenItem;
import net.mcreator.goodores.item.RawTinItem;
import net.mcreator.goodores.item.RawPlatinumItem;
import net.mcreator.goodores.item.PyriteFragmentItem;
import net.mcreator.goodores.item.PyriteChunkItem;
import net.mcreator.goodores.item.PlatinumSwordItem;
import net.mcreator.goodores.item.PlatinumShovelItem;
import net.mcreator.goodores.item.PlatinumPickaxeItem;
import net.mcreator.goodores.item.PlatinumNuggetItem;
import net.mcreator.goodores.item.PlatinumIngotItem;
import net.mcreator.goodores.item.PlatinumHoeItem;
import net.mcreator.goodores.item.PlatinumAxeItem;
import net.mcreator.goodores.item.PlatinumArmorItem;
import net.mcreator.goodores.item.OreScannerItem;
import net.mcreator.goodores.item.LumifloraSwordItem;
import net.mcreator.goodores.item.LumifloraShovelItem;
import net.mcreator.goodores.item.LumifloraPickaxeItem;
import net.mcreator.goodores.item.LumifloraNuggetItem;
import net.mcreator.goodores.item.LumifloraIngotItem;
import net.mcreator.goodores.item.LumifloraHoeItem;
import net.mcreator.goodores.item.LumifloraAxeItem;
import net.mcreator.goodores.item.LumifloraArmorItem;
import net.mcreator.goodores.item.LivingstoneSwordItem;
import net.mcreator.goodores.item.LivingstoneShovelItem;
import net.mcreator.goodores.item.LivingstoneShardItem;
import net.mcreator.goodores.item.LivingstonePickaxeItem;
import net.mcreator.goodores.item.LivingstoneHoeItem;
import net.mcreator.goodores.item.LivingstoneAxeItem;
import net.mcreator.goodores.item.LivingstoneArmorItem;
import net.mcreator.goodores.item.FrostbitePickaxeItem;
import net.mcreator.goodores.item.ExperienceCrystalItem;
import net.mcreator.goodores.item.BronzeIngotItem;
import net.mcreator.goodores.item.BronzeCrownRedstoneItem;
import net.mcreator.goodores.item.BronzeCrownLapizItem;
import net.mcreator.goodores.item.BronzeCrownItem;
import net.mcreator.goodores.item.BronzeCrownEmeraldItem;
import net.mcreator.goodores.item.BronzeCrownDiamondItem;
import net.mcreator.goodores.GoodOresMod;

import java.util.function.Function;

public class GoodOresModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(GoodOresMod.MODID);
	public static final DeferredItem<Item> PLATINUM_INGOT = register("platinum_ingot", PlatinumIngotItem::new);
	public static final DeferredItem<Item> PLATINUM_PICKAXE = register("platinum_pickaxe", PlatinumPickaxeItem::new);
	public static final DeferredItem<Item> PLATINUM_AXE = register("platinum_axe", PlatinumAxeItem::new);
	public static final DeferredItem<Item> PLATINUM_SWORD = register("platinum_sword", PlatinumSwordItem::new);
	public static final DeferredItem<Item> PLATINUM_SHOVEL = register("platinum_shovel", PlatinumShovelItem::new);
	public static final DeferredItem<Item> PLATINUM_HOE = register("platinum_hoe", PlatinumHoeItem::new);
	public static final DeferredItem<Item> PLATINUM_ARMOR_HELMET = register("platinum_armor_helmet", PlatinumArmorItem.Helmet::new);
	public static final DeferredItem<Item> PLATINUM_ARMOR_CHESTPLATE = register("platinum_armor_chestplate", PlatinumArmorItem.Chestplate::new);
	public static final DeferredItem<Item> PLATINUM_ARMOR_LEGGINGS = register("platinum_armor_leggings", PlatinumArmorItem.Leggings::new);
	public static final DeferredItem<Item> PLATINUM_ARMOR_BOOTS = register("platinum_armor_boots", PlatinumArmorItem.Boots::new);
	public static final DeferredItem<Item> PLATINUM_NUGGET = register("platinum_nugget", PlatinumNuggetItem::new);
	public static final DeferredItem<Item> RAW_PLATINUM = register("raw_platinum", RawPlatinumItem::new);
	public static final DeferredItem<Item> TIN_INGOT = register("tin_ingot", TinIngotItem::new);
	public static final DeferredItem<Item> TIN_PICKAXE = register("tin_pickaxe", TinPickaxeItem::new);
	public static final DeferredItem<Item> TIN_AXE = register("tin_axe", TinAxeItem::new);
	public static final DeferredItem<Item> TIN_SWORD = register("tin_sword", TinSwordItem::new);
	public static final DeferredItem<Item> TIN_SHOVEL = register("tin_shovel", TinShovelItem::new);
	public static final DeferredItem<Item> TIN_HOE = register("tin_hoe", TinHoeItem::new);
	public static final DeferredItem<Item> TIN_NUGGET = register("tin_nugget", TinNuggetItem::new);
	public static final DeferredItem<Item> RAW_TIN = register("raw_tin", RawTinItem::new);
	public static final DeferredItem<Item> TIN_ORE = block(GoodOresModBlocks.TIN_ORE);
	public static final DeferredItem<Item> DEEPSLATE_TIN_ORE = block(GoodOresModBlocks.DEEPSLATE_TIN_ORE);
	public static final DeferredItem<Item> PLATINUM_ORE = block(GoodOresModBlocks.PLATINUM_ORE);
	public static final DeferredItem<Item> DEEPSLATE_PLATINUM_ORE = block(GoodOresModBlocks.DEEPSLATE_PLATINUM_ORE);
	public static final DeferredItem<Item> RAW_TUNGSTEN = register("raw_tungsten", RawTungstenItem::new);
	public static final DeferredItem<Item> TUNGSTEN_INGOT = register("tungsten_ingot", TungstenIngotItem::new);
	public static final DeferredItem<Item> TUNGSTEN_NUGGET = register("tungsten_nugget", TungstenNuggetItem::new);
	public static final DeferredItem<Item> TUNGSTEN_ORE = block(GoodOresModBlocks.TUNGSTEN_ORE);
	public static final DeferredItem<Item> RAW_TIN_BLOCK = block(GoodOresModBlocks.RAW_TIN_BLOCK);
	public static final DeferredItem<Item> RAW_PLATINUM_BLOCK = block(GoodOresModBlocks.RAW_PLATINUM_BLOCK);
	public static final DeferredItem<Item> RAW_TUNGSTEN_BLOCK = block(GoodOresModBlocks.RAW_TUNGSTEN_BLOCK);
	public static final DeferredItem<Item> REINFORCED_NETHERITE_ARMOR_HELMET = register("reinforced_netherite_armor_helmet", ReinforcedNetheriteArmorItem.Helmet::new);
	public static final DeferredItem<Item> REINFORCED_NETHERITE_ARMOR_CHESTPLATE = register("reinforced_netherite_armor_chestplate", ReinforcedNetheriteArmorItem.Chestplate::new);
	public static final DeferredItem<Item> REINFORCED_NETHERITE_ARMOR_LEGGINGS = register("reinforced_netherite_armor_leggings", ReinforcedNetheriteArmorItem.Leggings::new);
	public static final DeferredItem<Item> REINFORCED_NETHERITE_ARMOR_BOOTS = register("reinforced_netherite_armor_boots", ReinforcedNetheriteArmorItem.Boots::new);
	public static final DeferredItem<Item> TUNGSTEN_PLAQUE = register("tungsten_plaque", TungstenPlaqueItem::new);
	public static final DeferredItem<Item> LIVINGSTONE_PLANT = block(GoodOresModBlocks.LIVINGSTONE_PLANT);
	public static final DeferredItem<Item> LIVINGSTONE_SHARD = register("livingstone_shard", LivingstoneShardItem::new);
	public static final DeferredItem<Item> LIVINGSTONE_PICKAXE = register("livingstone_pickaxe", LivingstonePickaxeItem::new);
	public static final DeferredItem<Item> LIVINGSTONE_AXE = register("livingstone_axe", LivingstoneAxeItem::new);
	public static final DeferredItem<Item> LIVINGSTONE_SWORD = register("livingstone_sword", LivingstoneSwordItem::new);
	public static final DeferredItem<Item> LIVINGSTONE_SHOVEL = register("livingstone_shovel", LivingstoneShovelItem::new);
	public static final DeferredItem<Item> LIVINGSTONE_HOE = register("livingstone_hoe", LivingstoneHoeItem::new);
	public static final DeferredItem<Item> LIVINGSTONE_BLOCK = block(GoodOresModBlocks.LIVINGSTONE_BLOCK);
	public static final DeferredItem<Item> LIVINGSTONE_ARMOR_HELMET = register("livingstone_armor_helmet", LivingstoneArmorItem.Helmet::new);
	public static final DeferredItem<Item> LIVINGSTONE_ARMOR_CHESTPLATE = register("livingstone_armor_chestplate", LivingstoneArmorItem.Chestplate::new);
	public static final DeferredItem<Item> LIVINGSTONE_ARMOR_LEGGINGS = register("livingstone_armor_leggings", LivingstoneArmorItem.Leggings::new);
	public static final DeferredItem<Item> LIVINGSTONE_ARMOR_BOOTS = register("livingstone_armor_boots", LivingstoneArmorItem.Boots::new);
	public static final DeferredItem<Item> TUNGSTEN_BLOCK = block(GoodOresModBlocks.TUNGSTEN_BLOCK);
	public static final DeferredItem<Item> TUNGSTEN_BRISK = block(GoodOresModBlocks.TUNGSTEN_BRISK);
	public static final DeferredItem<Item> PLATINUM_BLOCK = block(GoodOresModBlocks.PLATINUM_BLOCK);
	public static final DeferredItem<Item> PLATINUM_BARS = block(GoodOresModBlocks.PLATINUM_BARS);
	public static final DeferredItem<Item> TIN_BLOCK = block(GoodOresModBlocks.TIN_BLOCK);
	public static final DeferredItem<Item> REINFORCED_NETHERITE_BLOCK = block(GoodOresModBlocks.REINFORCED_NETHERITE_BLOCK);
	public static final DeferredItem<Item> VERDITE_PLANT = block(GoodOresModBlocks.VERDITE_PLANT);
	public static final DeferredItem<Item> VERDITE_NUGGET = register("verdite_nugget", VerditeNuggetItem::new);
	public static final DeferredItem<Item> VERDITE_INGOT = register("verdite_ingot", VerditeIngotItem::new);
	public static final DeferredItem<Item> VERDITE_PICKAXE = register("verdite_pickaxe", VerditePickaxeItem::new);
	public static final DeferredItem<Item> VERDITE_AXE = register("verdite_axe", VerditeAxeItem::new);
	public static final DeferredItem<Item> VERDITE_SWORD = register("verdite_sword", VerditeSwordItem::new);
	public static final DeferredItem<Item> VERDITE_SHOVEL = register("verdite_shovel", VerditeShovelItem::new);
	public static final DeferredItem<Item> VERDITE_HOE = register("verdite_hoe", VerditeHoeItem::new);
	public static final DeferredItem<Item> VERDITE_ARMOR_HELMET = register("verdite_armor_helmet", VerditeArmorItem.Helmet::new);
	public static final DeferredItem<Item> VERDITE_ARMOR_CHESTPLATE = register("verdite_armor_chestplate", VerditeArmorItem.Chestplate::new);
	public static final DeferredItem<Item> VERDITE_ARMOR_LEGGINGS = register("verdite_armor_leggings", VerditeArmorItem.Leggings::new);
	public static final DeferredItem<Item> VERDITE_ARMOR_BOOTS = register("verdite_armor_boots", VerditeArmorItem.Boots::new);
	public static final DeferredItem<Item> VERDITE_ROOTS = block(GoodOresModBlocks.VERDITE_ROOTS);
	public static final DeferredItem<Item> VERDITE_BLOCK = block(GoodOresModBlocks.VERDITE_BLOCK);
	public static final DeferredItem<Item> STEEL_HAMMER = register("steel_hammer", SteelHammerItem::new);
	public static final DeferredItem<Item> STEEL_DIGGER = register("steel_digger", SteelDiggerItem::new);
	public static final DeferredItem<Item> BRONZE_BLOCK = block(GoodOresModBlocks.BRONZE_BLOCK);
	public static final DeferredItem<Item> STEEL_BLOCK = block(GoodOresModBlocks.STEEL_BLOCK);
	public static final DeferredItem<Item> STEEL_GRATE = block(GoodOresModBlocks.STEEL_GRATE);
	public static final DeferredItem<Item> STEEL_GIANTSWORD = register("steel_giantsword", SteelGiantswordItem::new);
	public static final DeferredItem<Item> BIG_CHAIN = block(GoodOresModBlocks.BIG_CHAIN);
	public static final DeferredItem<Item> STEEL_DOOR = doubleBlock(GoodOresModBlocks.STEEL_DOOR);
	public static final DeferredItem<Item> STEEL_TRAPDOOR = block(GoodOresModBlocks.STEEL_TRAPDOOR);
	public static final DeferredItem<Item> HEAVY_PRESSURE_PLATE = block(GoodOresModBlocks.HEAVY_PRESSURE_PLATE);
	public static final DeferredItem<Item> STEEL_PILLAR = block(GoodOresModBlocks.STEEL_PILLAR);
	public static final DeferredItem<Item> PLATINUM_PRESSURE_PLATE = block(GoodOresModBlocks.PLATINUM_PRESSURE_PLATE);
	public static final DeferredItem<Item> VERDITE_APPLE = register("verdite_apple", VerditeAppleItem::new);
	public static final DeferredItem<Item> BRONZE_CROWN_EMERALD_HELMET = register("bronze_crown_emerald_helmet", BronzeCrownEmeraldItem.Helmet::new);
	public static final DeferredItem<Item> BRONZE_CROWN_DIAMOND_HELMET = register("bronze_crown_diamond_helmet", BronzeCrownDiamondItem.Helmet::new);
	public static final DeferredItem<Item> BRONZE_CROWN_REDSTONE_HELMET = register("bronze_crown_redstone_helmet", BronzeCrownRedstoneItem.Helmet::new);
	public static final DeferredItem<Item> BRONZE_CROWN_LAPIZ_HELMET = register("bronze_crown_lapiz_helmet", BronzeCrownLapizItem.Helmet::new);
	public static final DeferredItem<Item> BRONZE_INGOT = register("bronze_ingot", BronzeIngotItem::new);
	public static final DeferredItem<Item> STEEL_INGOT = register("steel_ingot", SteelIngotItem::new);
	public static final DeferredItem<Item> BRONZE_CROWN_HELMET = register("bronze_crown_helmet", BronzeCrownItem.Helmet::new);
	public static final DeferredItem<Item> STEEL_FURNACE = block(GoodOresModBlocks.STEEL_FURNACE);
	public static final DeferredItem<Item> TUMBAGA_INGOT = register("tumbaga_ingot", TumbagaIngotItem::new);
	public static final DeferredItem<Item> TUMBAGA_PICKAXE = register("tumbaga_pickaxe", TumbagaPickaxeItem::new);
	public static final DeferredItem<Item> TUMBAGA_AXE = register("tumbaga_axe", TumbagaAxeItem::new);
	public static final DeferredItem<Item> TUMBAGA_SWORD = register("tumbaga_sword", TumbagaSwordItem::new);
	public static final DeferredItem<Item> TUMBAGA_SHOVEL = register("tumbaga_shovel", TumbagaShovelItem::new);
	public static final DeferredItem<Item> TUMBAGA_HOE = register("tumbaga_hoe", TumbagaHoeItem::new);
	public static final DeferredItem<Item> TUMBAGA_CHISEL = register("tumbaga_chisel", TumbagaChiselItem::new);
	public static final DeferredItem<Item> TUMBAGA_BLOCK = block(GoodOresModBlocks.TUMBAGA_BLOCK);
	public static final DeferredItem<Item> CHISELED_TUNGSTEN_BLOCK = block(GoodOresModBlocks.CHISELED_TUNGSTEN_BLOCK);
	public static final DeferredItem<Item> CHISELED_TUNGSTEN_BRICK = block(GoodOresModBlocks.CHISELED_TUNGSTEN_BRICK);
	public static final DeferredItem<Item> VERDITE_BRICK = block(GoodOresModBlocks.VERDITE_BRICK);
	public static final DeferredItem<Item> LAVA_SPONGE = block(GoodOresModBlocks.LAVA_SPONGE);
	public static final DeferredItem<Item> WET_LAVA_SPONGE = block(GoodOresModBlocks.WET_LAVA_SPONGE);
	public static final DeferredItem<Item> STEEL_PLAQUE = register("steel_plaque", SteelPlaqueItem::new);
	public static final DeferredItem<Item> TIN_TILES = block(GoodOresModBlocks.TIN_TILES);
	public static final DeferredItem<Item> BRONZE_TILES = block(GoodOresModBlocks.BRONZE_TILES);
	public static final DeferredItem<Item> POLISHED_TUNGSTEN_BLOCK = block(GoodOresModBlocks.POLISHED_TUNGSTEN_BLOCK);
	public static final DeferredItem<Item> TIN_BRICKS = block(GoodOresModBlocks.TIN_BRICKS);
	public static final DeferredItem<Item> STEEL_BARS = block(GoodOresModBlocks.STEEL_BARS);
	public static final DeferredItem<Item> CUT_STEEL_BLOCK = block(GoodOresModBlocks.CUT_STEEL_BLOCK);
	public static final DeferredItem<Item> CUT_TUNGSTEN_BLOCK = block(GoodOresModBlocks.CUT_TUNGSTEN_BLOCK);
	public static final DeferredItem<Item> CUT_STEEL_STAIR = block(GoodOresModBlocks.CUT_STEEL_STAIR);
	public static final DeferredItem<Item> CUT_STEEL_SLAB = block(GoodOresModBlocks.CUT_STEEL_SLAB);
	public static final DeferredItem<Item> CUT_TUNGSTEN_SLAB = block(GoodOresModBlocks.CUT_TUNGSTEN_SLAB);
	public static final DeferredItem<Item> CUT_TUNGSTEN_STAIR = block(GoodOresModBlocks.CUT_TUNGSTEN_STAIR);
	public static final DeferredItem<Item> LUMIFLORA_INGOT = register("lumiflora_ingot", LumifloraIngotItem::new);
	public static final DeferredItem<Item> LUMIFLORA_PICKAXE = register("lumiflora_pickaxe", LumifloraPickaxeItem::new);
	public static final DeferredItem<Item> LUMIFLORA_AXE = register("lumiflora_axe", LumifloraAxeItem::new);
	public static final DeferredItem<Item> LUMIFLORA_SWORD = register("lumiflora_sword", LumifloraSwordItem::new);
	public static final DeferredItem<Item> LUMIFLORA_SHOVEL = register("lumiflora_shovel", LumifloraShovelItem::new);
	public static final DeferredItem<Item> LUMIFLORA_HOE = register("lumiflora_hoe", LumifloraHoeItem::new);
	public static final DeferredItem<Item> LUMIFLORA_NUGGET = register("lumiflora_nugget", LumifloraNuggetItem::new);
	public static final DeferredItem<Item> EXPERIENCE_ORE = block(GoodOresModBlocks.EXPERIENCE_ORE);
	public static final DeferredItem<Item> NETHER_EXPERIENCE_ORE = block(GoodOresModBlocks.NETHER_EXPERIENCE_ORE);
	public static final DeferredItem<Item> LUMIFLORA_PLANT = block(GoodOresModBlocks.LUMIFLORA_PLANT);
	public static final DeferredItem<Item> LUMIFLORA_BLOCK = block(GoodOresModBlocks.LUMIFLORA_BLOCK);
	public static final DeferredItem<Item> LUMIFLORA_BRICKS = block(GoodOresModBlocks.LUMIFLORA_BRICKS);
	public static final DeferredItem<Item> LUMIFLORA_TILES = block(GoodOresModBlocks.LUMIFLORA_TILES);
	public static final DeferredItem<Item> STEEL_ARMOR_HELMET = register("steel_armor_helmet", SteelArmorItem.Helmet::new);
	public static final DeferredItem<Item> STEEL_ARMOR_CHESTPLATE = register("steel_armor_chestplate", SteelArmorItem.Chestplate::new);
	public static final DeferredItem<Item> STEEL_ARMOR_LEGGINGS = register("steel_armor_leggings", SteelArmorItem.Leggings::new);
	public static final DeferredItem<Item> STEEL_ARMOR_BOOTS = register("steel_armor_boots", SteelArmorItem.Boots::new);
	public static final DeferredItem<Item> ORE_SCANNER = register("ore_scanner", OreScannerItem::new);
	public static final DeferredItem<Item> LUMIFLORA_ARMOR_HELMET = register("lumiflora_armor_helmet", LumifloraArmorItem.Helmet::new);
	public static final DeferredItem<Item> LUMIFLORA_ARMOR_CHESTPLATE = register("lumiflora_armor_chestplate", LumifloraArmorItem.Chestplate::new);
	public static final DeferredItem<Item> LUMIFLORA_ARMOR_LEGGINGS = register("lumiflora_armor_leggings", LumifloraArmorItem.Leggings::new);
	public static final DeferredItem<Item> LUMIFLORA_ARMOR_BOOTS = register("lumiflora_armor_boots", LumifloraArmorItem.Boots::new);
	public static final DeferredItem<Item> FROSTBITE_PICKAXE = register("frostbite_pickaxe", FrostbitePickaxeItem::new);
	public static final DeferredItem<Item> EXPERIENCE_CRYSTAL = register("experience_crystal", ExperienceCrystalItem::new);
	public static final DeferredItem<Item> PLATINUM_TILES = block(GoodOresModBlocks.PLATINUM_TILES);
	public static final DeferredItem<Item> PLATINUM_BRICKS = block(GoodOresModBlocks.PLATINUM_BRICKS);
	public static final DeferredItem<Item> GOLD_BRICKS = block(GoodOresModBlocks.GOLD_BRICKS);
	public static final DeferredItem<Item> GOLD_TILES = block(GoodOresModBlocks.GOLD_TILES);
	public static final DeferredItem<Item> PYRITE_FRAGMENT = register("pyrite_fragment", PyriteFragmentItem::new);
	public static final DeferredItem<Item> PYRITE_CHUNK = register("pyrite_chunk", PyriteChunkItem::new);
	public static final DeferredItem<Item> RUSTY_PICKAXE = register("rusty_pickaxe", RustyPickaxeItem::new);
	public static final DeferredItem<Item> RUSTY_AXE = register("rusty_axe", RustyAxeItem::new);

	// Start of user code block custom items
	//import net.minecraft.world.item.Items;
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new DoubleHighBlockItem(block.get(), properties), new Item.Properties());
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ItemsClientSideHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public static void registerItemModelProperties(RegisterRangeSelectItemModelPropertyEvent event) {
			event.register(ResourceLocation.parse("good_ores:ore_scanner/cd"), OreScannerItem.CdProperty.MAP_CODEC);
		}
	}
}
