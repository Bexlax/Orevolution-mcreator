package net.mcreator.goodores.configuration;

import net.neoforged.neoforge.common.ModConfigSpec;

public class GoodOresConfigConfiguration {
	public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
	public static final ModConfigSpec SPEC;

	public static final ModConfigSpec.ConfigValue<Boolean> STOP_ORE_BREAK;
	public static final ModConfigSpec.ConfigValue<Boolean> WARN_ORE_HARVEST;
	public static final ModConfigSpec.ConfigValue<Boolean> TOOLTIP_HARVEST_LEVEL;
	public static final ModConfigSpec.ConfigValue<Boolean> TIN_TRADES;
	public static final ModConfigSpec.ConfigValue<Boolean> PLATINUM_TRADES;
	public static final ModConfigSpec.ConfigValue<Boolean> TIN_PROGRESS;
	public static final ModConfigSpec.ConfigValue<Boolean> PLATINUM_PROGRESS;
	public static final ModConfigSpec.ConfigValue<Boolean> VANILLA_POWERS;
	public static final ModConfigSpec.ConfigValue<Boolean> MODDED_POWERS;

	public static final ModConfigSpec.ConfigValue<Boolean> DISABLE_TIN;
	public static final ModConfigSpec.ConfigValue<Boolean> DISABLE_PLATINUM;
	public static final ModConfigSpec.ConfigValue<Boolean> DISABLE_TUNGSTEN;
	public static final ModConfigSpec.ConfigValue<Boolean> DISABLE_ASTRAL;
	public static final ModConfigSpec.ConfigValue<Boolean> DISABLE_XPORE;
	public static final ModConfigSpec.ConfigValue<Boolean> DISABLE_LIVINGSTONE;
	public static final ModConfigSpec.ConfigValue<Boolean> DISABLE_VERDITE;
	static {
		BUILDER.push("QOL Config");
		STOP_ORE_BREAK = BUILDER.comment("Stops players from breaking ores if their current tool can't harvest it").define("stop player from breaking ore", false);
		WARN_ORE_HARVEST = BUILDER.comment("Warns the player if the tool he's using now can't harvest an ore").define("Warning for ore harvest", true);
		TOOLTIP_HARVEST_LEVEL = BUILDER.comment("Defines if a new tooltip with info about a tool's harvest level should be displayed").define("Harvest level on tooltip", true);
		TIN_TRADES = BUILDER.comment("Defines if a new tooltip with info about a tool's harvest level should be displayed").define("Enable tin trades for villagers", true);
		PLATINUM_TRADES = BUILDER.comment("Defines if a new tooltip with info about a tool's harvest level should be displayed").define("Enable platinum trades for villagers", true);
		BUILDER.pop();
		BUILDER.push("Modded Progress");
		TIN_PROGRESS = BUILDER.comment("Progress changes from [ Stone -> Iron ] to [ Stone -> Tin ->  Iron ]").define("Tin needed for iron", true);
		PLATINUM_PROGRESS = BUILDER.comment("Progress changes from [ Iron -> Diamond ] to [ Iron -> Platinum ->  Diamond ]").define("Platinum needed for Diamond", true);
		BUILDER.pop();
		BUILDER.push("Gameplay");
		VANILLA_POWERS = BUILDER.comment("Defines if vanilla equipment will have unique properties, like diamond dealing more damage to undead mobs").define("Vanilla equipment powers", true);
		MODDED_POWERS = BUILDER.comment("Defines if modded equipment will have unique properties, like tin increasing block drops").define("Modded equipment powers", true);
		BUILDER.push("Ore disabler");
		BUILDER.push("Mining Ores");
		DISABLE_TIN = BUILDER.comment("Defines if tin will be generated or not").define("Enable Tin", true);
		DISABLE_PLATINUM = BUILDER.comment("Defines if platinum will be generated or not").define("Enable Platinum", true);
		DISABLE_TUNGSTEN = BUILDER.comment("Defines if tungsten will be generated or not").define("Enable Tungsten", true);
		DISABLE_ASTRAL = BUILDER.comment("Defines if tungsten will be generated or not").define("Enable Astral", true);
		DISABLE_XPORE = BUILDER.comment("Defines if Experience ores will be generated or not").define("Enable Experience Ore", true);
		BUILDER.pop();
		BUILDER.push("Farming Ores");
		DISABLE_LIVINGSTONE = BUILDER.comment("Defines if livingstone will be obtainable or not").define("Enable Livingstone", true);
		DISABLE_VERDITE = BUILDER.comment("Defines if verdite will be obtainable or not").define("Enable Verdite", true);
		BUILDER.pop();
		BUILDER.pop();
		BUILDER.pop();

		SPEC = BUILDER.build();
	}

}
