
package net.mcreator.goodores.block;

import com.mojang.serialization.MapCodec;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.redstone.Orientation;
import net.mcreator.goodores.init.GoodOresModBlocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BucketPickup;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.SoundType;

public class LavaSpongeBlock extends Block {
	public static final MapCodec<LavaSpongeBlock> CODEC = simpleCodec(LavaSpongeBlock::new);
    public static final int MAX_DEPTH = 6;
    public static final int MAX_COUNT = 64;
    private static final Direction[] ALL_DIRECTIONS = Direction.values();

    @Override
    public MapCodec<LavaSpongeBlock> codec() {
        return CODEC;
    }
    
	public LavaSpongeBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.SPONGE).strength(3f, 16f).requiresCorrectToolForDrops());
	}

	@Override
    protected void onPlace(BlockState state, Level world, BlockPos pos, BlockState oldState, boolean p_56815_) {
        if (!oldState.is(state.getBlock())) {
            this.tryAbsorbLava(world, pos);
        }
    }

    @Override
    protected void neighborChanged(BlockState state, Level world, BlockPos pos, Block block, @Nullable Orientation orientation, boolean p_56806_) {
        this.tryAbsorbLava(world, pos);
        super.neighborChanged(state, world, pos, block, orientation, p_56806_);
    }

    protected void tryAbsorbLava(Level world, BlockPos pos) {
        if (this.removeLavaBreadthFirstSearch(world, pos)) {
            world.setBlock(pos, GoodOresModBlocks.WET_LAVA_SPONGE.get().defaultBlockState(), 2);
            world.playSound(null, pos, SoundEvents.LAVA_EXTINGUISH, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
    }

    private boolean removeLavaBreadthFirstSearch(Level world, BlockPos pos) {
        BlockState spongeState = world.getBlockState(pos);
        return BlockPos.breadthFirstTraversal(
                pos,
                6,
                65,
                (currentPos, consumer) -> {
                    for (Direction direction : ALL_DIRECTIONS) {
                        consumer.accept(currentPos.relative(direction));
                    }
                },
                targetPos -> {
                    if (targetPos.equals(pos)) {
                        return BlockPos.TraversalNodeStatus.ACCEPT;
                    } else {
                        BlockState targetState = world.getBlockState(targetPos);
                        FluidState fluidState = world.getFluidState(targetPos);
                        
                        // Check for Lava instead of Water
                        if (!fluidState.is(FluidTags.LAVA)) {
                            return BlockPos.TraversalNodeStatus.SKIP;
                        } else {
                            if (targetState.getBlock() instanceof BucketPickup bucketpickup
                                && !bucketpickup.pickupBlock(null, world, targetPos, targetState).isEmpty()) {
                                return BlockPos.TraversalNodeStatus.ACCEPT;
                            }

                            if (targetState.getBlock() instanceof LiquidBlock) {
                                world.setBlock(targetPos, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), 3);
                            } else {
                                return BlockPos.TraversalNodeStatus.SKIP;
                            }

                            return BlockPos.TraversalNodeStatus.ACCEPT;
                        }
                    }
                }
            ) > 1;
    }
}
