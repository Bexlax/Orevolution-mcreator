
package net.mcreator.goodores.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class LumifloraIngotItem extends Item {
	public LumifloraIngotItem(Item.Properties properties) {
		super(properties.rarity(Rarity.COMMON).stacksTo(64).fireResistant());
	}
}
