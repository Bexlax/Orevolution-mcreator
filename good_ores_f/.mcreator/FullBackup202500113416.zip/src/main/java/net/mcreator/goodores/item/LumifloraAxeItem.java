
package net.mcreator.goodores.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.CustomData;

public class LumifloraAxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1642, 8f, 0, 14, TagKey.create(Registries.ITEM, ResourceLocation.parse("good_ores:lumiflora_axe_repair_items")));

	public LumifloraAxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 7f, -3f, properties);
		CustomData.update(DataComponents.CUSTOM_DATA, this.getDefaultInstance(), tag -> tag.putBoolean("autosmelt", true));
	}
}
