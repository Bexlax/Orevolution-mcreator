
package net.mcreator.goodores.item;

import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.InteractionResult;
import net.minecraft.client.renderer.item.properties.numeric.RangeSelectItemModelProperty;
import net.minecraft.client.multiplayer.ClientLevel;

import net.mcreator.goodores.procedures.OreScannerPropertyCDProcedure;
import net.mcreator.goodores.procedures.OreScanProcedure;

import javax.annotation.Nullable;

import com.mojang.serialization.MapCodec;

public class OreScannerItem extends Item {
	public OreScannerItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON).stacksTo(1));
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		super.useOn(context);
		return OreScanProcedure.execute(context.getLevel(), context.getPlayer(), context.getItemInHand());
	}

	public record CdProperty() implements RangeSelectItemModelProperty {
		public static final MapCodec<CdProperty> MAP_CODEC = MapCodec.unit(new CdProperty());

		@Override
		public float get(ItemStack itemStackToRender, @Nullable ClientLevel clientWorld, @Nullable LivingEntity entity, int seed) {
			return (float) OreScannerPropertyCDProcedure.execute(entity, itemStackToRender);
		}

		@Override
		public MapCodec<CdProperty> type() {
			return MAP_CODEC;
		}
	}
}
