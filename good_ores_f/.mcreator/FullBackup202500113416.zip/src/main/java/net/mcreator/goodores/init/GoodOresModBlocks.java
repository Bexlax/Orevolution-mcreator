
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.goodores.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.goodores.block.WetLavaSpongeBlock;
import net.mcreator.goodores.block.VerditeRootsBlock;
import net.mcreator.goodores.block.VerditePlantBlock;
import net.mcreator.goodores.block.VerditeBrickBlock;
import net.mcreator.goodores.block.VerditeBlockBlock;
import net.mcreator.goodores.block.TungstenOreBlock;
import net.mcreator.goodores.block.TungstenBriskBlock;
import net.mcreator.goodores.block.TungstenBlockBlock;
import net.mcreator.goodores.block.TumbagaBlockBlock;
import net.mcreator.goodores.block.TinTilesBlock;
import net.mcreator.goodores.block.TinOreBlock;
import net.mcreator.goodores.block.TinBricksBlock;
import net.mcreator.goodores.block.TinBlockBlock;
import net.mcreator.goodores.block.SteelTrapdoorBlock;
import net.mcreator.goodores.block.SteelPillarBlock;
import net.mcreator.goodores.block.SteelGrateBlock;
import net.mcreator.goodores.block.SteelFurnaceBlock;
import net.mcreator.goodores.block.SteelDoorBlock;
import net.mcreator.goodores.block.SteelBlockBlock;
import net.mcreator.goodores.block.SteelBarsBlock;
import net.mcreator.goodores.block.ReinforcedNetheriteBlockBlock;
import net.mcreator.goodores.block.RawTungstenBlockBlock;
import net.mcreator.goodores.block.RawTinBlockBlock;
import net.mcreator.goodores.block.RawPlatinumBlockBlock;
import net.mcreator.goodores.block.PolishedTungstenBlockBlock;
import net.mcreator.goodores.block.PlatinumTilesBlock;
import net.mcreator.goodores.block.PlatinumPressurePlateBlock;
import net.mcreator.goodores.block.PlatinumOreBlock;
import net.mcreator.goodores.block.PlatinumBricksBlock;
import net.mcreator.goodores.block.PlatinumBlockBlock;
import net.mcreator.goodores.block.PlatinumBarsBlock;
import net.mcreator.goodores.block.NetherExperienceOreBlock;
import net.mcreator.goodores.block.LumifloraTilesBlock;
import net.mcreator.goodores.block.LumifloraPlantBlock;
import net.mcreator.goodores.block.LumifloraBricksBlock;
import net.mcreator.goodores.block.LumifloraBlockBlock;
import net.mcreator.goodores.block.LivingstonePlantBlock;
import net.mcreator.goodores.block.LivingstoneBlockBlock;
import net.mcreator.goodores.block.LavaSpongeBlock;
import net.mcreator.goodores.block.HeavyPressurePlateBlock;
import net.mcreator.goodores.block.GoldTilesBlock;
import net.mcreator.goodores.block.GoldBricksBlock;
import net.mcreator.goodores.block.ExperienceOreBlock;
import net.mcreator.goodores.block.DeepslateTinOreBlock;
import net.mcreator.goodores.block.DeepslatePlatinumOreBlock;
import net.mcreator.goodores.block.CutTungstenStairBlock;
import net.mcreator.goodores.block.CutTungstenSlabBlock;
import net.mcreator.goodores.block.CutTungstenBlockBlock;
import net.mcreator.goodores.block.CutSteelStairBlock;
import net.mcreator.goodores.block.CutSteelSlabBlock;
import net.mcreator.goodores.block.CutSteelBlockBlock;
import net.mcreator.goodores.block.ChiseledTungstenBrickBlock;
import net.mcreator.goodores.block.ChiseledTungstenBlockBlock;
import net.mcreator.goodores.block.BronzeTilesBlock;
import net.mcreator.goodores.block.BronzeBlockBlock;
import net.mcreator.goodores.block.BigChainBlock;
import net.mcreator.goodores.GoodOresMod;

import java.util.function.Function;

public class GoodOresModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(GoodOresMod.MODID);
	public static final DeferredBlock<Block> TIN_ORE = register("tin_ore", TinOreBlock::new);
	public static final DeferredBlock<Block> DEEPSLATE_TIN_ORE = register("deepslate_tin_ore", DeepslateTinOreBlock::new);
	public static final DeferredBlock<Block> PLATINUM_ORE = register("platinum_ore", PlatinumOreBlock::new);
	public static final DeferredBlock<Block> DEEPSLATE_PLATINUM_ORE = register("deepslate_platinum_ore", DeepslatePlatinumOreBlock::new);
	public static final DeferredBlock<Block> TUNGSTEN_ORE = register("tungsten_ore", TungstenOreBlock::new);
	public static final DeferredBlock<Block> RAW_TIN_BLOCK = register("raw_tin_block", RawTinBlockBlock::new);
	public static final DeferredBlock<Block> RAW_PLATINUM_BLOCK = register("raw_platinum_block", RawPlatinumBlockBlock::new);
	public static final DeferredBlock<Block> RAW_TUNGSTEN_BLOCK = register("raw_tungsten_block", RawTungstenBlockBlock::new);
	public static final DeferredBlock<Block> LIVINGSTONE_PLANT = register("livingstone_plant", LivingstonePlantBlock::new);
	public static final DeferredBlock<Block> LIVINGSTONE_BLOCK = register("livingstone_block", LivingstoneBlockBlock::new);
	public static final DeferredBlock<Block> TUNGSTEN_BLOCK = register("tungsten_block", TungstenBlockBlock::new);
	public static final DeferredBlock<Block> TUNGSTEN_BRISK = register("tungsten_brisk", TungstenBriskBlock::new);
	public static final DeferredBlock<Block> PLATINUM_BLOCK = register("platinum_block", PlatinumBlockBlock::new);
	public static final DeferredBlock<Block> PLATINUM_BARS = register("platinum_bars", PlatinumBarsBlock::new);
	public static final DeferredBlock<Block> TIN_BLOCK = register("tin_block", TinBlockBlock::new);
	public static final DeferredBlock<Block> REINFORCED_NETHERITE_BLOCK = register("reinforced_netherite_block", ReinforcedNetheriteBlockBlock::new);
	public static final DeferredBlock<Block> VERDITE_PLANT = register("verdite_plant", VerditePlantBlock::new);
	public static final DeferredBlock<Block> VERDITE_ROOTS = register("verdite_roots", VerditeRootsBlock::new);
	public static final DeferredBlock<Block> VERDITE_BLOCK = register("verdite_block", VerditeBlockBlock::new);
	public static final DeferredBlock<Block> BRONZE_BLOCK = register("bronze_block", BronzeBlockBlock::new);
	public static final DeferredBlock<Block> STEEL_BLOCK = register("steel_block", SteelBlockBlock::new);
	public static final DeferredBlock<Block> STEEL_GRATE = register("steel_grate", SteelGrateBlock::new);
	public static final DeferredBlock<Block> BIG_CHAIN = register("big_chain", BigChainBlock::new);
	public static final DeferredBlock<Block> STEEL_DOOR = register("steel_door", SteelDoorBlock::new);
	public static final DeferredBlock<Block> STEEL_TRAPDOOR = register("steel_trapdoor", SteelTrapdoorBlock::new);
	public static final DeferredBlock<Block> HEAVY_PRESSURE_PLATE = register("heavy_pressure_plate", HeavyPressurePlateBlock::new);
	public static final DeferredBlock<Block> STEEL_PILLAR = register("steel_pillar", SteelPillarBlock::new);
	public static final DeferredBlock<Block> PLATINUM_PRESSURE_PLATE = register("platinum_pressure_plate", PlatinumPressurePlateBlock::new);
	public static final DeferredBlock<Block> STEEL_FURNACE = register("steel_furnace", SteelFurnaceBlock::new);
	public static final DeferredBlock<Block> TUMBAGA_BLOCK = register("tumbaga_block", TumbagaBlockBlock::new);
	public static final DeferredBlock<Block> CHISELED_TUNGSTEN_BLOCK = register("chiseled_tungsten_block", ChiseledTungstenBlockBlock::new);
	public static final DeferredBlock<Block> CHISELED_TUNGSTEN_BRICK = register("chiseled_tungsten_brick", ChiseledTungstenBrickBlock::new);
	public static final DeferredBlock<Block> VERDITE_BRICK = register("verdite_brick", VerditeBrickBlock::new);
	public static final DeferredBlock<Block> LAVA_SPONGE = register("lava_sponge", LavaSpongeBlock::new);
	public static final DeferredBlock<Block> WET_LAVA_SPONGE = register("wet_lava_sponge", WetLavaSpongeBlock::new);
	public static final DeferredBlock<Block> TIN_TILES = register("tin_tiles", TinTilesBlock::new);
	public static final DeferredBlock<Block> BRONZE_TILES = register("bronze_tiles", BronzeTilesBlock::new);
	public static final DeferredBlock<Block> POLISHED_TUNGSTEN_BLOCK = register("polished_tungsten_block", PolishedTungstenBlockBlock::new);
	public static final DeferredBlock<Block> TIN_BRICKS = register("tin_bricks", TinBricksBlock::new);
	public static final DeferredBlock<Block> STEEL_BARS = register("steel_bars", SteelBarsBlock::new);
	public static final DeferredBlock<Block> CUT_STEEL_BLOCK = register("cut_steel_block", CutSteelBlockBlock::new);
	public static final DeferredBlock<Block> CUT_TUNGSTEN_BLOCK = register("cut_tungsten_block", CutTungstenBlockBlock::new);
	public static final DeferredBlock<Block> CUT_STEEL_STAIR = register("cut_steel_stair", CutSteelStairBlock::new);
	public static final DeferredBlock<Block> CUT_STEEL_SLAB = register("cut_steel_slab", CutSteelSlabBlock::new);
	public static final DeferredBlock<Block> CUT_TUNGSTEN_SLAB = register("cut_tungsten_slab", CutTungstenSlabBlock::new);
	public static final DeferredBlock<Block> CUT_TUNGSTEN_STAIR = register("cut_tungsten_stair", CutTungstenStairBlock::new);
	public static final DeferredBlock<Block> EXPERIENCE_ORE = register("experience_ore", ExperienceOreBlock::new);
	public static final DeferredBlock<Block> NETHER_EXPERIENCE_ORE = register("nether_experience_ore", NetherExperienceOreBlock::new);
	public static final DeferredBlock<Block> LUMIFLORA_PLANT = register("lumiflora_plant", LumifloraPlantBlock::new);
	public static final DeferredBlock<Block> LUMIFLORA_BLOCK = register("lumiflora_block", LumifloraBlockBlock::new);
	public static final DeferredBlock<Block> LUMIFLORA_BRICKS = register("lumiflora_bricks", LumifloraBricksBlock::new);
	public static final DeferredBlock<Block> LUMIFLORA_TILES = register("lumiflora_tiles", LumifloraTilesBlock::new);
	public static final DeferredBlock<Block> PLATINUM_TILES = register("platinum_tiles", PlatinumTilesBlock::new);
	public static final DeferredBlock<Block> PLATINUM_BRICKS = register("platinum_bricks", PlatinumBricksBlock::new);
	public static final DeferredBlock<Block> GOLD_BRICKS = register("gold_bricks", GoldBricksBlock::new);
	public static final DeferredBlock<Block> GOLD_TILES = register("gold_tiles", GoldTilesBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}
