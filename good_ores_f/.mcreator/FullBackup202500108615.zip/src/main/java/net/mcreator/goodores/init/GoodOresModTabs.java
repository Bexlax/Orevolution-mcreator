
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.goodores.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.goodores.GoodOresMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class GoodOresModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GoodOresMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(GoodOresModItems.PLATINUM_INGOT.get());
			tabData.accept(GoodOresModItems.PLATINUM_NUGGET.get());
			tabData.accept(GoodOresModItems.RAW_PLATINUM.get());
			tabData.accept(GoodOresModItems.TIN_INGOT.get());
			tabData.accept(GoodOresModItems.TIN_NUGGET.get());
			tabData.accept(GoodOresModItems.RAW_TIN.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(GoodOresModItems.PLATINUM_PICKAXE.get());
			tabData.accept(GoodOresModItems.PLATINUM_AXE.get());
			tabData.accept(GoodOresModItems.PLATINUM_SHOVEL.get());
			tabData.accept(GoodOresModItems.PLATINUM_HOE.get());
			tabData.accept(GoodOresModItems.TIN_PICKAXE.get());
			tabData.accept(GoodOresModItems.TIN_AXE.get());
			tabData.accept(GoodOresModItems.TIN_SHOVEL.get());
			tabData.accept(GoodOresModItems.TIN_HOE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(GoodOresModItems.PLATINUM_SWORD.get());
			tabData.accept(GoodOresModItems.PLATINUM_ARMOR_HELMET.get());
			tabData.accept(GoodOresModItems.PLATINUM_ARMOR_CHESTPLATE.get());
			tabData.accept(GoodOresModItems.PLATINUM_ARMOR_LEGGINGS.get());
			tabData.accept(GoodOresModItems.PLATINUM_ARMOR_BOOTS.get());
			tabData.accept(GoodOresModItems.TIN_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(GoodOresModBlocks.TIN_ORE.get().asItem());
			tabData.accept(GoodOresModBlocks.DEEPSLATE_TIN_ORE.get().asItem());
			tabData.accept(GoodOresModBlocks.PLATINUM_ORE.get().asItem());
			tabData.accept(GoodOresModBlocks.DEEPSLATE_PLATINUM_ORE.get().asItem());
		}
	}
}
