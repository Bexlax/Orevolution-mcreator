
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.goodores.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.goodores.block.TinOreBlock;
import net.mcreator.goodores.block.PlatinumOreBlock;
import net.mcreator.goodores.block.DeepslateTinOreBlock;
import net.mcreator.goodores.block.DeepslatePlatinumOreBlock;
import net.mcreator.goodores.GoodOresMod;

import java.util.function.Function;

public class GoodOresModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(GoodOresMod.MODID);
	public static final DeferredBlock<Block> TIN_ORE = register("tin_ore", TinOreBlock::new);
	public static final DeferredBlock<Block> DEEPSLATE_TIN_ORE = register("deepslate_tin_ore", DeepslateTinOreBlock::new);
	public static final DeferredBlock<Block> PLATINUM_ORE = register("platinum_ore", PlatinumOreBlock::new);
	public static final DeferredBlock<Block> DEEPSLATE_PLATINUM_ORE = register("deepslate_platinum_ore", DeepslatePlatinumOreBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}
