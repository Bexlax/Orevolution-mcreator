
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.goodores.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.goodores.potion.GoldPickaxeEffectMobEffect;
import net.mcreator.goodores.GoodOresMod;

public class GoodOresModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, GoodOresMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> GOLD_PICKAXE_EFFECT = REGISTRY.register("gold_pickaxe_effect", () -> new GoldPickaxeEffectMobEffect());
}
