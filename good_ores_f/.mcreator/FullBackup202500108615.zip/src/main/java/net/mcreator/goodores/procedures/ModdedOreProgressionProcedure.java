package net.mcreator.goodores.procedures;

import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.goodores.network.GoodOresModVariables;
import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;

import javax.annotation.Nullable;

@EventBusSubscriber
public class ModdedOreProgressionProcedure {
	@SubscribeEvent
	public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
		execute(event, event.getLevel().getBlockState(event.getPos()), event.getEntity());
	}

	public static void execute(BlockState blockstate, Entity entity) {
		execute(null, blockstate, entity);
	}

	private static void execute(@Nullable Event event, BlockState blockstate, Entity entity) {
		if (entity == null)
			return;
		{
			GoodOresModVariables.PlayerVariables _vars = entity.getData(GoodOresModVariables.PLAYER_VARIABLES);
			_vars.dontHarvestBlock = false;
			_vars.syncPlayerVariables(entity);
		}
		/* If modded ore progress is enabled, then continue */
		if (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("minecraft:iron_tools")))
				|| (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("minecraft:iron_tools")))) && GoodOresConfigConfiguration.PLATINUM_PROGRESS.get()) {
			/* Iron tools no longer break diamond */
			if (blockstate.is(BlockTags.create(ResourceLocation.parse("minecraft:diamond_blocks")))) {
				{
					GoodOresModVariables.PlayerVariables _vars = entity.getData(GoodOresModVariables.PLAYER_VARIABLES);
					_vars.dontHarvestBlock = true;
					_vars.syncPlayerVariables(entity);
				}
			}
		} else if (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("minecraft:stone_tools")))
				|| (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("minecraft:stone_tools")))) && GoodOresConfigConfiguration.TIN_PROGRESS.get()) {
			/* Stone tools no longer break iron */
			if (blockstate.is(BlockTags.create(ResourceLocation.parse("minecraft:iron_blocks")))) {
				{
					GoodOresModVariables.PlayerVariables _vars = entity.getData(GoodOresModVariables.PLAYER_VARIABLES);
					_vars.dontHarvestBlock = true;
					_vars.syncPlayerVariables(entity);
				}
			}
		}
	}
}
