package net.mcreator.goodores.procedures;

import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;

import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;

import javax.annotation.Nullable;

import java.util.List;

@EventBusSubscriber(value = {Dist.CLIENT})
public class AddTooltipForTierProcedure {
	@OnlyIn(Dist.CLIENT)
	@SubscribeEvent
	public static void onItemTooltip(ItemTooltipEvent event) {
		execute(event, event.getItemStack(), event.getToolTip());
	}

	public static void execute(ItemStack itemstack, List<Component> tooltip) {
		execute(null, itemstack, tooltip);
	}

	private static void execute(@Nullable Event event, ItemStack itemstack, List<Component> tooltip) {
		if (tooltip == null)
			return;
		/* Renders the new tooltip line 'Harvest tier' */
		if (GoodOresConfigConfiguration.TOOLTIP_HARVEST_LEVEL.get()) {
			if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:wood_tools")))) {
				tooltip.add(Component.literal((Component.translatable("tooltip.goodores.harvesttier").getString() + "" + Component.translatable("tooltip.goodores.stoneharvest").getString())));
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:stone_tools")))) {
				tooltip.add(Component.literal((Component.translatable("tooltip.goodores.harvesttier").getString() + ""
						+ Component.translatable((GoodOresConfigConfiguration.TIN_PROGRESS.get() ? "tooltip.goodores.tinharvest" : "tooltip.goodores.ironharvest")).getString())));
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:iron_tools")))) {
				tooltip.add(Component.literal((Component.translatable("tooltip.goodores.harvesttier").getString() + ""
						+ Component.translatable((GoodOresConfigConfiguration.PLATINUM_PROGRESS.get() ? "tooltip.goodores.platinumharvest" : "tooltip.goodores.diamondharvest")).getString())));
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:diamond_tools")))) {
				tooltip.add(Component.literal((Component.translatable("tooltip.goodores.harvesttier").getString() + "" + Component.translatable("tooltip.goodores.netheriteharvest").getString())));
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:netherite_tools")))) {
				tooltip.add(Component.literal((Component.translatable("tooltip.goodores.harvesttier").getString() + "" + Component.translatable("tooltip.goodores.allharvest").getString())));
			}
		}
	}
}
