
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.goodores.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.goodores.item.TinSwordItem;
import net.mcreator.goodores.item.TinShovelItem;
import net.mcreator.goodores.item.TinPickaxeItem;
import net.mcreator.goodores.item.TinNuggetItem;
import net.mcreator.goodores.item.TinIngotItem;
import net.mcreator.goodores.item.TinHoeItem;
import net.mcreator.goodores.item.TinAxeItem;
import net.mcreator.goodores.item.RawTinItem;
import net.mcreator.goodores.item.RawPlatinumItem;
import net.mcreator.goodores.item.PlatinumSwordItem;
import net.mcreator.goodores.item.PlatinumShovelItem;
import net.mcreator.goodores.item.PlatinumPickaxeItem;
import net.mcreator.goodores.item.PlatinumNuggetItem;
import net.mcreator.goodores.item.PlatinumIngotItem;
import net.mcreator.goodores.item.PlatinumHoeItem;
import net.mcreator.goodores.item.PlatinumAxeItem;
import net.mcreator.goodores.item.PlatinumArmorItem;
import net.mcreator.goodores.GoodOresMod;

import java.util.function.Function;

public class GoodOresModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(GoodOresMod.MODID);
	public static final DeferredItem<Item> PLATINUM_INGOT = register("platinum_ingot", PlatinumIngotItem::new);
	public static final DeferredItem<Item> PLATINUM_PICKAXE = register("platinum_pickaxe", PlatinumPickaxeItem::new);
	public static final DeferredItem<Item> PLATINUM_AXE = register("platinum_axe", PlatinumAxeItem::new);
	public static final DeferredItem<Item> PLATINUM_SWORD = register("platinum_sword", PlatinumSwordItem::new);
	public static final DeferredItem<Item> PLATINUM_SHOVEL = register("platinum_shovel", PlatinumShovelItem::new);
	public static final DeferredItem<Item> PLATINUM_HOE = register("platinum_hoe", PlatinumHoeItem::new);
	public static final DeferredItem<Item> PLATINUM_ARMOR_HELMET = register("platinum_armor_helmet", PlatinumArmorItem.Helmet::new);
	public static final DeferredItem<Item> PLATINUM_ARMOR_CHESTPLATE = register("platinum_armor_chestplate", PlatinumArmorItem.Chestplate::new);
	public static final DeferredItem<Item> PLATINUM_ARMOR_LEGGINGS = register("platinum_armor_leggings", PlatinumArmorItem.Leggings::new);
	public static final DeferredItem<Item> PLATINUM_ARMOR_BOOTS = register("platinum_armor_boots", PlatinumArmorItem.Boots::new);
	public static final DeferredItem<Item> PLATINUM_NUGGET = register("platinum_nugget", PlatinumNuggetItem::new);
	public static final DeferredItem<Item> RAW_PLATINUM = register("raw_platinum", RawPlatinumItem::new);
	public static final DeferredItem<Item> TIN_INGOT = register("tin_ingot", TinIngotItem::new);
	public static final DeferredItem<Item> TIN_PICKAXE = register("tin_pickaxe", TinPickaxeItem::new);
	public static final DeferredItem<Item> TIN_AXE = register("tin_axe", TinAxeItem::new);
	public static final DeferredItem<Item> TIN_SWORD = register("tin_sword", TinSwordItem::new);
	public static final DeferredItem<Item> TIN_SHOVEL = register("tin_shovel", TinShovelItem::new);
	public static final DeferredItem<Item> TIN_HOE = register("tin_hoe", TinHoeItem::new);
	public static final DeferredItem<Item> TIN_NUGGET = register("tin_nugget", TinNuggetItem::new);
	public static final DeferredItem<Item> RAW_TIN = register("raw_tin", RawTinItem::new);
	public static final DeferredItem<Item> TIN_ORE = block(GoodOresModBlocks.TIN_ORE);
	public static final DeferredItem<Item> DEEPSLATE_TIN_ORE = block(GoodOresModBlocks.DEEPSLATE_TIN_ORE);
	public static final DeferredItem<Item> PLATINUM_ORE = block(GoodOresModBlocks.PLATINUM_ORE);
	public static final DeferredItem<Item> DEEPSLATE_PLATINUM_ORE = block(GoodOresModBlocks.DEEPSLATE_PLATINUM_ORE);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}
}
