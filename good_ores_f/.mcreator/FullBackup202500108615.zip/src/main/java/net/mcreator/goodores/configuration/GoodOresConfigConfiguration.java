package net.mcreator.goodores.configuration;

import net.neoforged.neoforge.common.ModConfigSpec;

public class GoodOresConfigConfiguration {
	public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
	public static final ModConfigSpec SPEC;

	public static final ModConfigSpec.ConfigValue<Boolean> STOP_ORE_BREAK;
	public static final ModConfigSpec.ConfigValue<Boolean> WARN_ORE_HARVEST;
	public static final ModConfigSpec.ConfigValue<Boolean> TOOLTIP_HARVEST_LEVEL;
	public static final ModConfigSpec.ConfigValue<Boolean> TIN_PROGRESS;
	public static final ModConfigSpec.ConfigValue<Boolean> PLATINUM_PROGRESS;
	public static final ModConfigSpec.ConfigValue<Boolean> VANILLA_POWERS;
	static {
		BUILDER.push("QOL Config");
		STOP_ORE_BREAK = BUILDER.comment("Stops players from breaking ores if their current tool can't harvest it").define("stop player from breaking ore", false);
		WARN_ORE_HARVEST = BUILDER.comment("Warns the player if the tool he's using now can't harvest an ore").define("Warning for ore harvest", true);
		TOOLTIP_HARVEST_LEVEL = BUILDER.comment("Defines if a new tooltip with info about a tool's harvest level should be displayed").define("Harvest level on tooltip", true);
		BUILDER.pop();
		BUILDER.push("Modded Progress");
		TIN_PROGRESS = BUILDER.comment("Progress changes from [ Stone -> Iron ] to [ Stone -> Tin ->  Iron ]").define("Tin needed for iron", true);
		PLATINUM_PROGRESS = BUILDER.comment("Progress changes from [ Iron -> Diamond ] to [ Iron -> Platinum ->  Diamond ]").define("Platinum needed for Diamond", true);
		BUILDER.pop();
		BUILDER.push("Gameplay Mechanics");
		VANILLA_POWERS = BUILDER.comment("Defines things like diamond dealing extra damage to undead mobs").define("Vanilla tool powers", true);
		BUILDER.pop();

		SPEC = BUILDER.build();
	}

}
