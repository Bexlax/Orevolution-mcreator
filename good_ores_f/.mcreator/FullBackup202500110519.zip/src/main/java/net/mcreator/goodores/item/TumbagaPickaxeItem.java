
package net.mcreator.goodores.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class TumbagaPickaxeItem extends PickaxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_STONE_TOOL, 294, 9f, 0, 26, TagKey.create(Registries.ITEM, ResourceLocation.parse("good_ores:tumbaga_pickaxe_repair_items")));

	public TumbagaPickaxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 2f, -2.6f, properties);
	}
}
