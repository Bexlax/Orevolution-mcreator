
package net.mcreator.goodores.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.DoorBlock;

public class SteelDoorBlock extends DoorBlock {
	public SteelDoorBlock(BlockBehaviour.Properties properties) {
		super(BlockSetType.IRON, properties.mapColor(MapColor.COLOR_GRAY).sound(SoundType.GILDED_BLACKSTONE).strength(5f, 16f).requiresCorrectToolForDrops().noOcclusion().pushReaction(PushReaction.BLOCK).isRedstoneConductor((bs, br, bp) -> false));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 0;
	}
}
