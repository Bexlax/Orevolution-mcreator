package net.mcreator.goodores.procedures;

import net.neoforged.neoforge.event.entity.player.CriticalHitEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;

import javax.annotation.Nullable;

@EventBusSubscriber
public class VerditeToolsEffectProcedure {
	@SubscribeEvent
	public static void onPlayerCriticalHit(CriticalHitEvent event) {
		execute(event, event.getTarget(), event.isVanillaCritical());
	}

	public static void execute(Entity entity, boolean isvanillacritical) {
		execute(null, entity, isvanillacritical);
	}

	private static void execute(@Nullable Event event, Entity entity, boolean isvanillacritical) {
		if (entity == null)
			return;
		if (GoodOresConfigConfiguration.MODDED_POWERS.get()) {
			if (isvanillacritical) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 0));
			}
		}
	}
}
