package net.mcreator.goodores.procedures;

import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;

import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;

import javax.annotation.Nullable;

import java.util.List;

@EventBusSubscriber(value = {Dist.CLIENT})
public class AddTooltipForTierProcedure {
	@OnlyIn(Dist.CLIENT)
	@SubscribeEvent
	public static void onItemTooltip(ItemTooltipEvent event) {
		execute(event, event.getItemStack(), event.getToolTip());
	}

	public static void execute(ItemStack itemstack, List<Component> tooltip) {
		execute(null, itemstack, tooltip);
	}

	private static void execute(@Nullable Event event, ItemStack itemstack, List<Component> tooltip) {
		if (tooltip == null)
			return;
		String return_string = "";
		/* Renders the new tooltip line 'Harvest tier' */
		if (GoodOresConfigConfiguration.TOOLTIP_HARVEST_LEVEL.get()) {
			if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:wood_tools"))) || itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:gold_tools")))) {
				return_string = "stone";
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:stone_tools")))) {
				return_string = GoodOresConfigConfiguration.TIN_PROGRESS.get() ? "tin" : "iron";
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:iron_tools")))) {
				return_string = GoodOresConfigConfiguration.PLATINUM_PROGRESS.get() ? "platinum" : "diamond";
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:diamond_tools"))) || itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:netherite_tools")))) {
				return_string = "netherite";
			}
		}
		if (!(itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:modded_tools"))) || (return_string).isEmpty())) {
			tooltip.add(2, Component.literal((Component.translatable("tooltip.goodores.harvesttier").getString() + "" + Component.translatable(("tooltip.goodores." + return_string + "harvest")).getString())));
		}
	}
}
