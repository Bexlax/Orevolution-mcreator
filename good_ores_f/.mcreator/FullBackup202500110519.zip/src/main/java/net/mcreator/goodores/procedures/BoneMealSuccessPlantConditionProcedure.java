package net.mcreator.goodores.procedures;

import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;

public class BoneMealSuccessPlantConditionProcedure {
	public static boolean execute(LevelAccessor world, BlockState blockstate) {
		return !((blockstate.getBlock().getStateDefinition().getProperty("age") instanceof IntegerProperty _getip1 ? blockstate.getValue(_getip1) : -1) >= (blockstate.getBlock().getStateDefinition().getProperty("age") instanceof IntegerProperty _max3
				? _max3.getPossibleValues().stream().max(Integer::compareTo).get()
				: -1));
	}
}
