package net.mcreator.goodores.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.Entity;

import net.mcreator.goodores.network.GoodOresModVariables;

import javax.annotation.Nullable;

@EventBusSubscriber
public class PlantEquipmentTimerProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		{
			GoodOresModVariables.PlayerVariables _vars = entity.getData(GoodOresModVariables.PLAYER_VARIABLES);
			_vars.PlantEquipmentTicker = entity.getData(GoodOresModVariables.PLAYER_VARIABLES).PlantEquipmentTicker + 1;
			_vars.syncPlayerVariables(entity);
		}
		if (entity.getData(GoodOresModVariables.PLAYER_VARIABLES).PlantEquipmentTicker > 160) {
			{
				GoodOresModVariables.PlayerVariables _vars = entity.getData(GoodOresModVariables.PLAYER_VARIABLES);
				_vars.PlantEquipmentTicker = 0;
				_vars.syncPlayerVariables(entity);
			}
		}
	}
}
