package net.mcreator.goodores.procedures;

import net.neoforged.neoforge.event.entity.player.CriticalHitEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.goodores.init.GoodOresModMobEffects;
import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;

import javax.annotation.Nullable;

@EventBusSubscriber
public class SteelCauseBleedingProcedure {
	@SubscribeEvent
	public static void onPlayerCriticalHit(CriticalHitEvent event) {
		execute(event, event.getTarget(), event.isVanillaCritical());
	}

	public static void execute(Entity entity, boolean isvanillacritical) {
		execute(null, entity, isvanillacritical);
	}

	private static void execute(@Nullable Event event, Entity entity, boolean isvanillacritical) {
		if (entity == null)
			return;
		if (GoodOresConfigConfiguration.MODDED_POWERS.get() && isvanillacritical) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).is(ItemTags.create(ResourceLocation.parse("minecraft:steel_tools")))) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(GoodOresModMobEffects.BLEEDING, 160, 0));
			}
		}
	}
}
