package net.mcreator.goodores.procedures;

import net.minecraft.network.chat.Component;

import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;

public class SteelToolsTooltipProcedure {
	public static String execute() {
		if (GoodOresConfigConfiguration.TOOLTIP_HARVEST_LEVEL.get()) {
			return Component.translatable("tooltip.goodores.breakmore").getString() + "\n" + Component.translatable("tooltip.goodores.harvesttier").getString() + Component.translatable("tooltip.goodores.diamondharvest").getString();
		}
		return "YOU SHOULDN'T SEE THIS TEXT!!!!";
	}
}
