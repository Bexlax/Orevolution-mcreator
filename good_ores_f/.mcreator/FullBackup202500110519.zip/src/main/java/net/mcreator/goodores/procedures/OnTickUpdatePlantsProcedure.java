package net.mcreator.goodores.procedures;

import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.BlockPos;

public class OnTickUpdatePlantsProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		if (Mth.nextInt(RandomSource.create(), 0, 2) == 0 && (blockstate.getBlock().getStateDefinition().getProperty("age") instanceof IntegerProperty _getip2
				? blockstate.getValue(_getip2)
				: -1) < (blockstate.getBlock().getStateDefinition().getProperty("age") instanceof IntegerProperty _max4 ? _max4.getPossibleValues().stream().max(Integer::compareTo).get() : -1)) {
			{
				int _value = (int) ((blockstate.getBlock().getStateDefinition().getProperty("age") instanceof IntegerProperty _getip6 ? blockstate.getValue(_getip6) : -1) + 1);
				BlockPos _pos = BlockPos.containing(x, y, z);
				BlockState _bs = world.getBlockState(_pos);
				if (_bs.getBlock().getStateDefinition().getProperty("age") instanceof IntegerProperty _integerProp && _integerProp.getPossibleValues().contains(_value))
					world.setBlock(_pos, _bs.setValue(_integerProp, _value), 3);
			}
		}
	}
}
