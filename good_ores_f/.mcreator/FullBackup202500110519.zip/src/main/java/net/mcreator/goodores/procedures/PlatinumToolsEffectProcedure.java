package net.mcreator.goodores.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;

import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;

public class PlatinumToolsEffectProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		double MaxFallDistance = 0;
		/* Deal 35% more damage if armor value of target is bigger than 0 */
		if (GoodOresConfigConfiguration.MODDED_POWERS.get()) {
			entity.hurt(new DamageSource(world.holderOrThrow(DamageTypes.PLAYER_ATTACK)),
					(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getArmorValue() : 0) > 0 ? (entity instanceof LivingEntity _livEnt ? _livEnt.getArmorValue() : 0) * 0.35 : 0));
		}
	}
}
