package net.mcreator.goodores.procedures;

import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;

import javax.annotation.Nullable;

import java.util.List;

@EventBusSubscriber(value = {Dist.CLIENT})
public class AddTooltipForArmorBonusProcedure {
	@OnlyIn(Dist.CLIENT)
	@SubscribeEvent
	public static void onItemTooltip(ItemTooltipEvent event) {
		execute(event, event.getItemStack(), event.getToolTip());
	}

	public static void execute(ItemStack itemstack, List<Component> tooltip) {
		execute(null, itemstack, tooltip);
	}

	private static void execute(@Nullable Event event, ItemStack itemstack, List<Component> tooltip) {
		if (tooltip == null)
			return;
		String return_text = "";
		if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:full_iron")))) {
			tooltip.add(1, Component.literal(
					(Component.translatable("tooltip.goodores.setbonus").getString() + "\n" + Component.translatable("tooltip.goodores.bonusiron_one").getString() + "\n" + Component.translatable("tooltip.goodores.bonusiron_two").getString())));
		} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:full_chainmail")))) {
			tooltip.add(1, Component.literal((Component.translatable("tooltip.goodores.setbonus").getString() + "\n" + Component.translatable("tooltip.goodores.bonuschainmail").getString())));
		} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("minecraft:full_gold")))) {
			tooltip.add(1,
					Component.literal(
							(Component.translatable("tooltip.goodores.setbonus").getString() + "\n" + Component.translatable("tooltip.goodores.bonusgold_one").getString() + "\n" + Component.translatable("tooltip.goodores.bonusgold_two").getString()
									+ "\n" + Component.translatable("tooltip.goodores.bonusgold_three").getString() + "\n" + Component.translatable("tooltip.goodores.bonusgold_four").getString())));
		}
	}
}
