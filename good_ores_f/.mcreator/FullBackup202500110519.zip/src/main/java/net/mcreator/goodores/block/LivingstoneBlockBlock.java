
package net.mcreator.goodores.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class LivingstoneBlockBlock extends Block {
	public LivingstoneBlockBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.CALCITE).strength(5.35f, 8f).requiresCorrectToolForDrops());
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}
