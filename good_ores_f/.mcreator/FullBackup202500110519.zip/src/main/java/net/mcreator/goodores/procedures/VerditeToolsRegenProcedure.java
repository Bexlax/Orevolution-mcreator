package net.mcreator.goodores.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.goodores.network.GoodOresModVariables;
import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;

public class VerditeToolsRegenProcedure {
	public static void execute(LevelAccessor world, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (GoodOresConfigConfiguration.MODDED_POWERS.get()) {
			if (entity.getData(GoodOresModVariables.PLAYER_VARIABLES).PlantEquipmentTicker % 160 == 0) {
				if (world instanceof ServerLevel _level) {
					itemstack.hurtAndBreak(-1, _level, null, _stkprov -> {
					});
				}
			}
		}
	}
}
