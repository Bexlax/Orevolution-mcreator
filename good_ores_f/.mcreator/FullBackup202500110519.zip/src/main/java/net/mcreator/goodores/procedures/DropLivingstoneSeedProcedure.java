package net.mcreator.goodores.procedures;

import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.goodores.init.GoodOresModBlocks;
import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;

import javax.annotation.Nullable;

@EventBusSubscriber
public class DropLivingstoneSeedProcedure {
	@SubscribeEvent
	public static void onBlockBreak(BlockEvent.BreakEvent event) {
		execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getState());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		execute(null, world, x, y, z, blockstate);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		if (GoodOresConfigConfiguration.DISABLE_LIVINGSTONE.get() && blockstate.is(BlockTags.create(ResourceLocation.parse("minecraft:crops")))
				&& (blockstate.getBlock().getStateDefinition().getProperty("age") instanceof IntegerProperty _getip4
						? blockstate.getValue(_getip4)
						: -1) >= (blockstate.getBlock().getStateDefinition().getProperty("age") instanceof IntegerProperty _max6 ? _max6.getPossibleValues().stream().max(Integer::compareTo).get() : -1)) {
			if ((world.getBlockState(BlockPos.containing(x, y - 2, z))).getBlock() == Blocks.STONE || (world.getBlockState(BlockPos.containing(x, y - 2, z))).getBlock() == Blocks.COBBLESTONE) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(GoodOresModBlocks.LIVINGSTONE_PLANT.get()));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			} else if ((world.getBlockState(BlockPos.containing(x, y - 2, z))).getBlock() == GoodOresModBlocks.LIVINGSTONE_BLOCK.get()) {
				for (int index0 = 0; index0 < Mth.nextInt(RandomSource.create(), 1, 2); index0++) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(GoodOresModBlocks.LIVINGSTONE_PLANT.get()));
						entityToSpawn.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn);
					}
				}
			}
		}
	}
}
