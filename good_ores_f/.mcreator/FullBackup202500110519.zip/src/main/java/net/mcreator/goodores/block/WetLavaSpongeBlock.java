
package net.mcreator.goodores.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;

import net.mcreator.goodores.procedures.WetLavaSpongeBlockAddedProcedure;

public class WetLavaSpongeBlock extends Block {
	public WetLavaSpongeBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.SPONGE).strength(3f, 16f).requiresCorrectToolForDrops());
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		WetLavaSpongeBlockAddedProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}
}
