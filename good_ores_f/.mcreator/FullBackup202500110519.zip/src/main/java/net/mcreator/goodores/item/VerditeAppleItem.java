
package net.mcreator.goodores.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;

import net.mcreator.goodores.procedures.VerditeAppleApplyEffectsProcedure;

public class VerditeAppleItem extends Item {
	public VerditeAppleItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE).stacksTo(64).food((new FoodProperties.Builder()).nutrition(2).saturationModifier(10f).alwaysEdible().build()));
	}

	@Override
	public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
		ItemStack retval = super.finishUsingItem(itemstack, world, entity);
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		VerditeAppleApplyEffectsProcedure.execute(world, x, y, z, entity, itemstack);
		return retval;
	}
}
