package net.mcreator.goodores.procedures;

import net.mcreator.goodores.configuration.GoodOresConfigConfiguration;

public class CheckForTungstenPlacementConfigProcedure {
	public static boolean execute() {
		return GoodOresConfigConfiguration.DISABLE_TUNGSTEN.get();
	}
}
