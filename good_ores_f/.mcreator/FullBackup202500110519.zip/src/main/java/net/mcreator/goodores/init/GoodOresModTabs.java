
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.goodores.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.goodores.GoodOresMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class GoodOresModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GoodOresMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(GoodOresModItems.PLATINUM_INGOT.get());
			tabData.accept(GoodOresModItems.PLATINUM_NUGGET.get());
			tabData.accept(GoodOresModItems.RAW_PLATINUM.get());
			tabData.accept(GoodOresModItems.TIN_INGOT.get());
			tabData.accept(GoodOresModItems.TIN_NUGGET.get());
			tabData.accept(GoodOresModItems.RAW_TIN.get());
			tabData.accept(GoodOresModItems.RAW_TUNGSTEN.get());
			tabData.accept(GoodOresModItems.TUNGSTEN_INGOT.get());
			tabData.accept(GoodOresModItems.TUNGSTEN_NUGGET.get());
			tabData.accept(GoodOresModItems.TUNGSTEN_PLAQUE.get());
			tabData.accept(GoodOresModItems.LIVINGSTONE_SHARD.get());
			tabData.accept(GoodOresModItems.BRONZE_INGOT.get());
			tabData.accept(GoodOresModItems.TUMBAGA_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(GoodOresModItems.PLATINUM_PICKAXE.get());
			tabData.accept(GoodOresModItems.PLATINUM_AXE.get());
			tabData.accept(GoodOresModItems.PLATINUM_SHOVEL.get());
			tabData.accept(GoodOresModItems.PLATINUM_HOE.get());
			tabData.accept(GoodOresModItems.TIN_PICKAXE.get());
			tabData.accept(GoodOresModItems.TIN_AXE.get());
			tabData.accept(GoodOresModItems.TIN_SHOVEL.get());
			tabData.accept(GoodOresModItems.TIN_HOE.get());
			tabData.accept(GoodOresModItems.LIVINGSTONE_PICKAXE.get());
			tabData.accept(GoodOresModItems.LIVINGSTONE_AXE.get());
			tabData.accept(GoodOresModItems.LIVINGSTONE_SHOVEL.get());
			tabData.accept(GoodOresModItems.LIVINGSTONE_HOE.get());
			tabData.accept(GoodOresModItems.VERDITE_PICKAXE.get());
			tabData.accept(GoodOresModItems.VERDITE_AXE.get());
			tabData.accept(GoodOresModItems.VERDITE_SHOVEL.get());
			tabData.accept(GoodOresModItems.VERDITE_HOE.get());
			tabData.accept(GoodOresModItems.STEEL_HAMMER.get());
			tabData.accept(GoodOresModItems.STEEL_DIGGER.get());
			tabData.accept(GoodOresModItems.TUMBAGA_PICKAXE.get());
			tabData.accept(GoodOresModItems.TUMBAGA_AXE.get());
			tabData.accept(GoodOresModItems.TUMBAGA_SHOVEL.get());
			tabData.accept(GoodOresModItems.TUMBAGA_HOE.get());
			tabData.accept(GoodOresModItems.TUMBAGA_CHISEL.get());
			tabData.accept(GoodOresModBlocks.LAVA_SPONGE.get().asItem());
			tabData.accept(GoodOresModBlocks.WET_LAVA_SPONGE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(GoodOresModItems.PLATINUM_SWORD.get());
			tabData.accept(GoodOresModItems.PLATINUM_ARMOR_HELMET.get());
			tabData.accept(GoodOresModItems.PLATINUM_ARMOR_CHESTPLATE.get());
			tabData.accept(GoodOresModItems.PLATINUM_ARMOR_LEGGINGS.get());
			tabData.accept(GoodOresModItems.PLATINUM_ARMOR_BOOTS.get());
			tabData.accept(GoodOresModItems.TIN_SWORD.get());
			tabData.accept(GoodOresModItems.REINFORCED_NETHERITE_ARMOR_HELMET.get());
			tabData.accept(GoodOresModItems.REINFORCED_NETHERITE_ARMOR_CHESTPLATE.get());
			tabData.accept(GoodOresModItems.REINFORCED_NETHERITE_ARMOR_LEGGINGS.get());
			tabData.accept(GoodOresModItems.REINFORCED_NETHERITE_ARMOR_BOOTS.get());
			tabData.accept(GoodOresModItems.LIVINGSTONE_SWORD.get());
			tabData.accept(GoodOresModItems.LIVINGSTONE_ARMOR_HELMET.get());
			tabData.accept(GoodOresModItems.LIVINGSTONE_ARMOR_CHESTPLATE.get());
			tabData.accept(GoodOresModItems.LIVINGSTONE_ARMOR_LEGGINGS.get());
			tabData.accept(GoodOresModItems.LIVINGSTONE_ARMOR_BOOTS.get());
			tabData.accept(GoodOresModItems.VERDITE_SWORD.get());
			tabData.accept(GoodOresModItems.VERDITE_ARMOR_HELMET.get());
			tabData.accept(GoodOresModItems.VERDITE_ARMOR_CHESTPLATE.get());
			tabData.accept(GoodOresModItems.VERDITE_ARMOR_LEGGINGS.get());
			tabData.accept(GoodOresModItems.VERDITE_ARMOR_BOOTS.get());
			tabData.accept(GoodOresModItems.STEEL_GIANTSWORD.get());
			tabData.accept(GoodOresModItems.BRONZE_CROWN_EMERALD_HELMET.get());
			tabData.accept(GoodOresModItems.BRONZE_CROWN_DIAMOND_HELMET.get());
			tabData.accept(GoodOresModItems.BRONZE_CROWN_REDSTONE_HELMET.get());
			tabData.accept(GoodOresModItems.BRONZE_CROWN_LAPIZ_HELMET.get());
			tabData.accept(GoodOresModItems.BRONZE_CROWN_HELMET.get());
			tabData.accept(GoodOresModItems.TUMBAGA_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(GoodOresModBlocks.TIN_ORE.get().asItem());
			tabData.accept(GoodOresModBlocks.DEEPSLATE_TIN_ORE.get().asItem());
			tabData.accept(GoodOresModBlocks.PLATINUM_ORE.get().asItem());
			tabData.accept(GoodOresModBlocks.DEEPSLATE_PLATINUM_ORE.get().asItem());
			tabData.accept(GoodOresModBlocks.TUNGSTEN_ORE.get().asItem());
			tabData.accept(GoodOresModBlocks.RAW_TIN_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.RAW_PLATINUM_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.RAW_TUNGSTEN_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.LIVINGSTONE_PLANT.get().asItem());
			tabData.accept(GoodOresModBlocks.VERDITE_PLANT.get().asItem());
			tabData.accept(GoodOresModBlocks.VERDITE_ROOTS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(GoodOresModBlocks.LIVINGSTONE_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.TUNGSTEN_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.TUNGSTEN_BRISK.get().asItem());
			tabData.accept(GoodOresModBlocks.PLATINUM_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.PLATINUM_BARS.get().asItem());
			tabData.accept(GoodOresModBlocks.TIN_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.REINFORCED_NETHERITE_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.VERDITE_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.BRONZE_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.STEEL_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.STEEL_GRATE.get().asItem());
			tabData.accept(GoodOresModBlocks.BIG_CHAIN.get().asItem());
			tabData.accept(GoodOresModBlocks.STEEL_DOOR.get().asItem());
			tabData.accept(GoodOresModBlocks.STEEL_PILLAR.get().asItem());
			tabData.accept(GoodOresModBlocks.TUMBAGA_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.CHISELED_TUNGSTEN_BLOCK.get().asItem());
			tabData.accept(GoodOresModBlocks.CHISELED_TUNGSTEN_BRICK.get().asItem());
			tabData.accept(GoodOresModBlocks.VERDITE_BRICK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(GoodOresModBlocks.STEEL_TRAPDOOR.get().asItem());
			tabData.accept(GoodOresModBlocks.HEAVY_PRESSURE_PLATE.get().asItem());
			tabData.accept(GoodOresModBlocks.PLATINUM_PRESSURE_PLATE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(GoodOresModItems.VERDITE_APPLE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(GoodOresModBlocks.STEEL_FURNACE.get().asItem());
			tabData.accept(GoodOresModBlocks.LAVA_SPONGE.get().asItem());
			tabData.accept(GoodOresModBlocks.WET_LAVA_SPONGE.get().asItem());
		}
	}
}
